-- Canonical JSON codec for the Journal channel.
--
-- Pure Lua 5.4 built-ins only: no dynamic module loading, no native
-- libraries, no ambient input/output. Encoding is deterministic: object
-- keys are sorted in byte order, integers render as decimal digits,
-- finite floats render in their shortest round-trip form, strings must
-- be valid UTF-8 and receive the minimum JSON escaping. Decoding is
-- strict: exact JSON grammar, string object keys, duplicate-key
-- rejection, no null support, no trailing content, and finite depth,
-- entry-count, string-size, and total-byte bounds.
--
-- json.encode(value, limits) -> text | nil, message
-- json.decode(text, limits) -> value | nil, message
--
-- limits may be nil or a table with any of max_depth, max_entries,
-- max_string_bytes, max_bytes; omitted fields use json.DEFAULTS and
-- every supplied field must be a positive integer not exceeding
-- json.HARD_LIMITS. For encode, max_bytes bounds the produced text;
-- for decode, it bounds the input text.
--
-- Error messages begin with a stable code: E_LIMIT, E_DEPTH,
-- E_ENTRIES, E_STRING, E_UTF8, E_NUMBER, E_KEY, E_VALUE, E_OUTPUT,
-- E_INPUT, E_SYNTAX, E_DUPLICATE, E_TRAILING.

local json = {}

local LIMIT_NAMES = { "max_depth", "max_entries", "max_string_bytes", "max_bytes" }

local function freeze(values)
    return setmetatable({}, {
        __index = values,
        __newindex = function()
            error("json: limit tables are immutable", 2)
        end,
    })
end

json.DEFAULTS = freeze({
    max_depth = 32,
    max_entries = 4096,
    max_string_bytes = 65536,
    max_bytes = 262144,
})

json.HARD_LIMITS = freeze({
    max_depth = 256,
    max_entries = 1048576,
    max_string_bytes = 1048576,
    max_bytes = 16777216,
})

local function resolve_limits(provided)
    if provided ~= nil and type(provided) ~= "table" then
        return nil, "E_LIMIT: limits must be a table"
    end
    local resolved = {}
    for _, name in ipairs(LIMIT_NAMES) do
        local value = provided and provided[name] or nil
        if value == nil then
            resolved[name] = json.DEFAULTS[name]
        elseif type(value) ~= "number" or math.type(value) ~= "integer" or value < 1 or value > json.HARD_LIMITS[name] then
            return nil, "E_LIMIT: " .. name .. " must be a positive integer within hard bounds"
        else
            resolved[name] = value
        end
    end
    if provided ~= nil then
        for key in next, provided do
            if resolved[key] == nil then
                return nil, "E_LIMIT: unknown limit field"
            end
        end
    end
    return resolved
end

-- Strict UTF-8 validation: shortest encodings only, no surrogate code
-- points, nothing above U+10FFFF.
local function utf8_valid(text)
    local length = #text
    local index = 1
    while index <= length do
        local byte = text:byte(index)
        if byte <= 0x7f then
            index = index + 1
        elseif byte >= 0xc2 and byte <= 0xdf then
            if index + 1 > length then
                return false
            end
            local b2 = text:byte(index + 1)
            if b2 < 0x80 or b2 > 0xbf then
                return false
            end
            index = index + 2
        elseif byte >= 0xe0 and byte <= 0xef then
            if index + 2 > length then
                return false
            end
            local b2 = text:byte(index + 1)
            local b3 = text:byte(index + 2)
            if byte == 0xe0 then
                if b2 < 0xa0 or b2 > 0xbf then
                    return false
                end
            elseif byte == 0xed then
                if b2 < 0x80 or b2 > 0x9f then
                    return false
                end
            elseif b2 < 0x80 or b2 > 0xbf then
                return false
            end
            if b3 < 0x80 or b3 > 0xbf then
                return false
            end
            index = index + 3
        elseif byte >= 0xf0 and byte <= 0xf4 then
            if index + 3 > length then
                return false
            end
            local b2 = text:byte(index + 1)
            local b3 = text:byte(index + 2)
            local b4 = text:byte(index + 3)
            if byte == 0xf0 then
                if b2 < 0x90 or b2 > 0xbf then
                    return false
                end
            elseif byte == 0xf4 then
                if b2 < 0x80 or b2 > 0x8f then
                    return false
                end
            elseif b2 < 0x80 or b2 > 0xbf then
                return false
            end
            if b3 < 0x80 or b3 > 0xbf or b4 < 0x80 or b4 > 0xbf then
                return false
            end
            index = index + 4
        else
            return false
        end
    end
    return true
end

local ESCAPES = {
    ['"'] = '\\"',
    ["\\"] = "\\\\",
    ["\b"] = "\\b",
    ["\f"] = "\\f",
    ["\n"] = "\\n",
    ["\r"] = "\\r",
    ["\t"] = "\\t",
}

local function encode_string(text, limits)
    if #text > limits.max_string_bytes then
        return nil, "E_STRING: string exceeds max_string_bytes"
    end
    if not utf8_valid(text) then
        return nil, "E_UTF8: string is not valid UTF-8"
    end
    local parts = { '"' }
    local length = #text
    local cursor = 1
    while cursor <= length do
        local char = text:sub(cursor, cursor)
        local escaped = ESCAPES[char]
        if escaped ~= nil then
            parts[#parts + 1] = escaped
            cursor = cursor + 1
        elseif text:byte(cursor) < 0x20 then
            parts[#parts + 1] = string.format("\\u%04x", text:byte(cursor))
            cursor = cursor + 1
        else
            local start = cursor
            while cursor < length do
                local next_char = text:sub(cursor + 1, cursor + 1)
                if ESCAPES[next_char] ~= nil or text:byte(cursor + 1) < 0x20 then
                    break
                end
                cursor = cursor + 1
            end
            parts[#parts + 1] = text:sub(start, cursor)
            cursor = cursor + 1
        end
    end
    parts[#parts + 1] = '"'
    return table.concat(parts)
end

local function encode_number(value)
    if math.type(value) == "integer" then
        return string.format("%d", value)
    end
    if value ~= value or value == math.huge or value == -math.huge then
        return nil, "E_NUMBER: non-finite numbers are not encodable"
    end
    for precision = 1, 17 do
        local text = string.format("%." .. precision .. "g", value)
        if tonumber(text) == value then
            if text:find("[eE%.]") == nil then
                text = text .. ".0"
            end
            return text
        end
    end
    return nil, "E_NUMBER: number is not formattable"
end

local encode_value

local function append(chunks, state, limits, text)
    state.bytes = state.bytes + #text
    if state.bytes > limits.max_bytes then
        return nil, "E_OUTPUT: encoded output exceeds max_bytes"
    end
    chunks[#chunks + 1] = text
    return true
end

local function encode_table(value, depth, limits, chunks, state)
    if depth > limits.max_depth then
        return nil, "E_DEPTH: nesting exceeds max_depth"
    end
    local count, max_index, integer_keys, string_keys = 0, 0, 0, 0
    for key in next, value do
        count = count + 1
        local key_type = type(key)
        if key_type == "string" then
            string_keys = string_keys + 1
        elseif key_type == "number" and math.type(key) == "integer" and key >= 1 then
            integer_keys = integer_keys + 1
            if key > max_index then
                max_index = key
            end
        else
            return nil, "E_KEY: table keys must be strings or positive integers"
        end
    end
    if integer_keys > 0 and string_keys > 0 then
        return nil, "E_KEY: table mixes string and integer keys"
    end
    if integer_keys > 0 and count ~= max_index then
        return nil, "E_KEY: array indices must be consecutive from 1"
    end
    state.entries = state.entries + count
    if state.entries > limits.max_entries then
        return nil, "E_ENTRIES: table entries exceed max_entries"
    end
    if string_keys == 0 then
        local ok, err = append(chunks, state, limits, "[")
        if ok == nil then
            return nil, err
        end
        for index = 1, count do
            if index > 1 then
                ok, err = append(chunks, state, limits, ",")
                if ok == nil then
                    return nil, err
                end
            end
            ok, err = encode_value(value[index], depth + 1, limits, chunks, state)
            if ok == nil then
                return nil, err
            end
        end
        ok, err = append(chunks, state, limits, "]")
        if ok == nil then
            return nil, err
        end
        return true
    end
    local keys = {}
    for key in next, value do
        keys[#keys + 1] = key
    end
    table.sort(keys)
    local ok, err = append(chunks, state, limits, "{")
    if ok == nil then
        return nil, err
    end
    for index = 1, #keys do
        if index > 1 then
            ok, err = append(chunks, state, limits, ",")
            if ok == nil then
                return nil, err
            end
        end
        local key_text
        key_text, err = encode_string(keys[index], limits)
        if key_text == nil then
            return nil, err
        end
        ok, err = append(chunks, state, limits, key_text)
        if ok == nil then
            return nil, err
        end
        ok, err = append(chunks, state, limits, ":")
        if ok == nil then
            return nil, err
        end
        ok, err = encode_value(value[keys[index]], depth + 1, limits, chunks, state)
        if ok == nil then
            return nil, err
        end
    end
    ok, err = append(chunks, state, limits, "}")
    if ok == nil then
        return nil, err
    end
    return true
end

encode_value = function(value, depth, limits, chunks, state)
    local kind = type(value)
    if kind == "nil" then
        return nil, "E_VALUE: nil is not encodable"
    end
    if kind == "boolean" then
        return append(chunks, state, limits, value and "true" or "false")
    end
    if kind == "number" then
        local text, err = encode_number(value)
        if text == nil then
            return nil, err
        end
        return append(chunks, state, limits, text)
    end
    if kind == "string" then
        local text, err = encode_string(value, limits)
        if text == nil then
            return nil, err
        end
        return append(chunks, state, limits, text)
    end
    if kind == "table" then
        return encode_table(value, depth, limits, chunks, state)
    end
    return nil, "E_VALUE: cannot encode values of type " .. kind
end

function json.encode(value, limits)
    local resolved, err = resolve_limits(limits)
    if resolved == nil then
        return nil, err
    end
    local chunks = {}
    local state = { entries = 0, bytes = 0 }
    local ok
    ok, err = encode_value(value, 1, resolved, chunks, state)
    if ok == nil then
        return nil, err
    end
    return table.concat(chunks)
end

local function skip_whitespace(text, pos)
    local length = #text
    while pos <= length do
        local byte = text:byte(pos)
        if byte == 0x20 or byte == 0x09 or byte == 0x0a or byte == 0x0d then
            pos = pos + 1
        else
            break
        end
    end
    return pos
end

local function hex_digit(byte)
    if byte >= 0x30 and byte <= 0x39 then
        return byte - 0x30
    end
    if byte >= 0x61 and byte <= 0x66 then
        return byte - 0x61 + 10
    end
    if byte >= 0x41 and byte <= 0x46 then
        return byte - 0x41 + 10
    end
    return nil
end

local function codepoint_to_utf8(codepoint)
    if codepoint <= 0x7f then
        return string.char(codepoint)
    end
    if codepoint <= 0x7ff then
        return string.char(0xc0 + (codepoint >> 6), 0x80 + (codepoint & 0x3f))
    end
    if codepoint <= 0xffff then
        return string.char(0xe0 + (codepoint >> 12), 0x80 + ((codepoint >> 6) & 0x3f), 0x80 + (codepoint & 0x3f))
    end
    return string.char(0xf0 + (codepoint >> 18), 0x80 + ((codepoint >> 12) & 0x3f), 0x80 + ((codepoint >> 6) & 0x3f), 0x80 + (codepoint & 0x3f))
end

local function parse_string(text, limits, state)
    local length = #text
    local pos = state.pos + 1
    local parts = {}
    while true do
        if pos > length then
            return nil, "E_SYNTAX: unterminated string"
        end
        local byte = text:byte(pos)
        if byte == 0x22 then
            pos = pos + 1
            break
        elseif byte == 0x5c then
            if pos + 1 > length then
                return nil, "E_SYNTAX: unterminated escape"
            end
            local escaped = text:byte(pos + 1)
            local replacement
            if escaped == 0x22 then
                replacement = '"'
            elseif escaped == 0x5c then
                replacement = "\\"
            elseif escaped == 0x2f then
                replacement = "/"
            elseif escaped == 0x62 then
                replacement = "\b"
            elseif escaped == 0x66 then
                replacement = "\f"
            elseif escaped == 0x6e then
                replacement = "\n"
            elseif escaped == 0x72 then
                replacement = "\r"
            elseif escaped == 0x74 then
                replacement = "\t"
            elseif escaped == 0x75 then
                if pos + 5 > length then
                    return nil, "E_SYNTAX: truncated unicode escape"
                end
                local codepoint = 0
                for offset = 2, 5 do
                    local digit = hex_digit(text:byte(pos + offset))
                    if digit == nil then
                        return nil, "E_UTF8: invalid hex digit in unicode escape"
                    end
                    codepoint = codepoint * 16 + digit
                end
                if codepoint >= 0xd800 and codepoint <= 0xdbff then
                    if pos + 11 > length or text:byte(pos + 6) ~= 0x5c or text:byte(pos + 7) ~= 0x75 then
                        return nil, "E_UTF8: unpaired high surrogate"
                    end
                    local low = 0
                    for offset = 8, 11 do
                        local digit = hex_digit(text:byte(pos + offset))
                        if digit == nil then
                            return nil, "E_UTF8: invalid hex digit in unicode escape"
                        end
                        low = low * 16 + digit
                    end
                    if low < 0xdc00 or low > 0xdfff then
                        return nil, "E_UTF8: unpaired surrogate"
                    end
                    codepoint = 0x10000 + ((codepoint - 0xd800) << 10) + (low - 0xdc00)
                    pos = pos + 6
                elseif codepoint >= 0xdc00 and codepoint <= 0xdfff then
                    return nil, "E_UTF8: unpaired low surrogate"
                end
                replacement = codepoint_to_utf8(codepoint)
                pos = pos + 4
            else
                return nil, "E_UTF8: invalid escape character"
            end
            parts[#parts + 1] = replacement
            pos = pos + 2
        elseif byte < 0x20 then
            return nil, "E_UTF8: unescaped control character in string"
        else
            local start = pos
            while pos < length do
                local next_byte = text:byte(pos + 1)
                if next_byte == 0x22 or next_byte == 0x5c or next_byte < 0x20 then
                    break
                end
                pos = pos + 1
            end
            parts[#parts + 1] = text:sub(start, pos)
            pos = pos + 1
        end
    end
    local decoded = table.concat(parts)
    if #decoded > limits.max_string_bytes then
        return nil, "E_STRING: string exceeds max_string_bytes"
    end
    if not utf8_valid(decoded) then
        return nil, "E_UTF8: string is not valid UTF-8"
    end
    state.pos = pos
    return decoded
end

local MIN_INTEGER_MAGNITUDE_PREFIX = 922337203685477580

local function parse_number(text, limits, state)
    local length = #text
    local start = state.pos
    local pos = start
    local negative = false
    if text:byte(pos) == 0x2d then
        negative = true
        pos = pos + 1
        if pos > length then
            return nil, "E_SYNTAX: number has a lone minus"
        end
    end
    local first = text:byte(pos)
    if first < 0x30 or first > 0x39 then
        return nil, "E_SYNTAX: invalid number"
    end
    if first == 0x30 then
        pos = pos + 1
        if pos <= length then
            local next_byte = text:byte(pos)
            if next_byte >= 0x30 and next_byte <= 0x39 then
                return nil, "E_NUMBER: leading zeros are not allowed"
            end
        end
    else
        while pos <= length do
            local next_byte = text:byte(pos)
            if next_byte < 0x30 or next_byte > 0x39 then
                break
            end
            pos = pos + 1
        end
    end
    local fractional = false
    if pos <= length and text:byte(pos) == 0x2e then
        fractional = true
        pos = pos + 1
        local digits = 0
        while pos <= length do
            local next_byte = text:byte(pos)
            if next_byte < 0x30 or next_byte > 0x39 then
                break
            end
            digits = digits + 1
            pos = pos + 1
        end
        if digits == 0 then
            return nil, "E_SYNTAX: number has no fractional digits"
        end
    end
    if pos <= length then
        local exponent_marker = text:byte(pos)
        if exponent_marker == 0x65 or exponent_marker == 0x45 then
            fractional = true
            pos = pos + 1
            if pos <= length then
                local sign = text:byte(pos)
                if sign == 0x2b or sign == 0x2d then
                    pos = pos + 1
                end
            end
            local digits = 0
            while pos <= length do
                local next_byte = text:byte(pos)
                if next_byte < 0x30 or next_byte > 0x39 then
                    break
                end
                digits = digits + 1
                pos = pos + 1
            end
            if digits == 0 then
                return nil, "E_SYNTAX: number has no exponent digits"
            end
        end
    end
    local token = text:sub(start, pos - 1)
    state.pos = pos
    if not fractional then
        local digits = negative and token:sub(2) or token
        local magnitude = 0
        for index = 1, #digits do
            local digit = digits:byte(index) - 0x30
            if magnitude > (math.maxinteger - digit) // 10 then
                if negative and magnitude == MIN_INTEGER_MAGNITUDE_PREFIX and digit == 8 and index == #digits then
                    return math.mininteger
                end
                return nil, "E_NUMBER: integer out of range"
            end
            magnitude = magnitude * 10 + digit
        end
        if negative then
            return -magnitude
        end
        return magnitude
    end
    local value = tonumber(token)
    if value == nil or value ~= value or value == math.huge or value == -math.huge then
        return nil, "E_NUMBER: number is not finite"
    end
    return value
end

local parse_value

local function parse_array(text, limits, state, depth)
    local result = {}
    state.pos = state.pos + 1
    state.pos = skip_whitespace(text, state.pos)
    if state.pos > #text then
        return nil, "E_SYNTAX: unterminated array"
    end
    if text:byte(state.pos) == 0x5d then
        state.pos = state.pos + 1
        return result
    end
    while true do
        local value, err = parse_value(text, limits, state, depth + 1)
        if value == nil then
            return nil, err
        end
        result[#result + 1] = value
        state.entries = state.entries + 1
        if state.entries > limits.max_entries then
            return nil, "E_ENTRIES: table entries exceed max_entries"
        end
        state.pos = skip_whitespace(text, state.pos)
        if state.pos > #text then
            return nil, "E_SYNTAX: unterminated array"
        end
        local byte = text:byte(state.pos)
        if byte == 0x5d then
            state.pos = state.pos + 1
            return result
        end
        if byte ~= 0x2c then
            return nil, "E_SYNTAX: expected comma or closing bracket in array"
        end
        state.pos = state.pos + 1
    end
end

local function parse_object(text, limits, state, depth)
    local result = {}
    local seen = {}
    state.pos = state.pos + 1
    state.pos = skip_whitespace(text, state.pos)
    if state.pos > #text then
        return nil, "E_SYNTAX: unterminated object"
    end
    if text:byte(state.pos) == 0x7d then
        state.pos = state.pos + 1
        return result
    end
    while true do
        state.pos = skip_whitespace(text, state.pos)
        if state.pos > #text or text:byte(state.pos) ~= 0x22 then
            return nil, "E_SYNTAX: expected string object key"
        end
        local key, err = parse_string(text, limits, state)
        if key == nil then
            return nil, err
        end
        if seen[key] then
            return nil, "E_DUPLICATE: duplicate object key"
        end
        seen[key] = true
        state.pos = skip_whitespace(text, state.pos)
        if state.pos > #text or text:byte(state.pos) ~= 0x3a then
            return nil, "E_SYNTAX: expected colon after object key"
        end
        state.pos = state.pos + 1
        local value
        value, err = parse_value(text, limits, state, depth + 1)
        if value == nil then
            return nil, err
        end
        result[key] = value
        state.entries = state.entries + 1
        if state.entries > limits.max_entries then
            return nil, "E_ENTRIES: table entries exceed max_entries"
        end
        state.pos = skip_whitespace(text, state.pos)
        if state.pos > #text then
            return nil, "E_SYNTAX: unterminated object"
        end
        local byte = text:byte(state.pos)
        if byte == 0x7d then
            state.pos = state.pos + 1
            return result
        end
        if byte ~= 0x2c then
            return nil, "E_SYNTAX: expected comma or closing brace in object"
        end
        state.pos = state.pos + 1
    end
end

parse_value = function(text, limits, state, depth)
    if depth > limits.max_depth then
        return nil, "E_DEPTH: nesting exceeds max_depth"
    end
    local length = #text
    local pos = skip_whitespace(text, state.pos)
    state.pos = pos
    if pos > length then
        return nil, "E_SYNTAX: unexpected end of input"
    end
    local byte = text:byte(pos)
    if byte == 0x74 then
        if text:sub(pos, pos + 3) ~= "true" then
            return nil, "E_SYNTAX: invalid literal"
        end
        state.pos = pos + 4
        return true
    end
    if byte == 0x66 then
        if text:sub(pos, pos + 4) ~= "false" then
            return nil, "E_SYNTAX: invalid literal"
        end
        state.pos = pos + 5
        return false
    end
    if byte == 0x6e then
        if text:sub(pos, pos + 3) ~= "null" then
            return nil, "E_SYNTAX: invalid literal"
        end
        return nil, "E_VALUE: null is not supported"
    end
    if byte == 0x22 then
        return parse_string(text, limits, state)
    end
    if byte == 0x5b then
        return parse_array(text, limits, state, depth)
    end
    if byte == 0x7b then
        return parse_object(text, limits, state, depth)
    end
    if byte == 0x2d or (byte >= 0x30 and byte <= 0x39) then
        return parse_number(text, limits, state)
    end
    return nil, "E_SYNTAX: unexpected character"
end

function json.decode(text, limits)
    if type(text) ~= "string" then
        return nil, "E_INPUT: input must be a string"
    end
    if #text == 0 then
        return nil, "E_INPUT: input is empty"
    end
    local resolved, err = resolve_limits(limits)
    if resolved == nil then
        return nil, err
    end
    if #text > resolved.max_bytes then
        return nil, "E_INPUT: input exceeds max_bytes"
    end
    local state = { pos = 1, entries = 0 }
    local value, parse_error = parse_value(text, resolved, state, 1)
    if value == nil then
        return nil, parse_error or "E_SYNTAX: invalid value"
    end
    local pos = skip_whitespace(text, state.pos)
    if pos <= #text then
        return nil, "E_TRAILING: content after top-level value"
    end
    return value
end

return json
