-- Journal Channel: portable journal implementation in pure Lua.
--
-- Durable state model (all paths relative to the read-write `output` mount):
--   YYYY/YYYY-MM/YYYY-MM-DD/entries/<entry-id>/states/state-NNNNNN.json
--   YYYY/YYYY-MM/YYYY-MM-DD/entries/<entry-id>/capture.wav
--   YYYY/YYYY-MM/YYYY-MM-DD/entries/<entry-id>/recording.ogg
--   YYYY/YYYY-MM/YYYY-MM-DD/journal-day-YYYY-MM-DD.md
--
-- Each snapshot is a complete canonical-JSON document (never a delta), created
-- with write_text mode "create-new" at the next contiguous fixed-width
-- sequence. Recovery trusts only the highest valid contiguous sequence and
-- treats malformed or noncontiguous trailing state as uncommitted.
local channel = require("subspace.channel")
local runtime = require("subspace.runtime")
local fs = require("subspace.fs")
local audio = require("subspace.audio")
local transcription = require("subspace.transcription")
local log = require("subspace.log")
local json = require("json")

local SCHEMA_VERSION = 1
local SNAPSHOT_WIDTH = 6
local MAX_SEQUENCE = 999999
local MAX_SNAPSHOTS_PER_ENTRY = 128
local MAX_TRANSCRIPT_BYTES = 65536
local MAX_SESSION_BYTES = 256
local ENCODE_LIMITS = {
    max_depth = 6,
    max_entries = 128,
    max_string_bytes = MAX_TRANSCRIPT_BYTES + 512,
    max_bytes = 262144,
}
local DECODE_LIMITS = {
    max_depth = 6,
    max_entries = 128,
    max_string_bytes = MAX_TRANSCRIPT_BYTES + 512,
    max_bytes = 262144,
}
local SNAPSHOT_READ_MAX = 262144
local MARKDOWN_READ_MAX = 1048576
local LIST_PAGE_LIMIT = 50
local LIST_MAX_PAGES = 200
local RECOVERY_OP_BUDGET = 4096
local WAV_HEADER_BYTES = 44

local CAPTURE_STATES = {
    recording = true,
    finished = true,
    deleted = true,
    failed = true,
    abandoned = true,
}
local DERIVATIVE_STATES = {
    skipped = true,
    pending = true,
    running = true,
    finished = true,
    failed = true,
}
-- Errors that mean "stop immediately; the generation or execution is going
-- away", so no further durable state may be published.
local STOP_ERRORS = {
    E_CANCELLED = true,
    E_CLOSED = true,
    E_STALE = true,
}

local OUTPUT_MODES = {
    VOICE = true,
    TRANSCRIPT = true,
    VOICE_AND_TRANSCRIPT = true,
}
local MODE_CAPABILITIES = {
    VOICE = { "storage.files", "audio.files" },
    TRANSCRIPT = { "storage.files", "audio.files", "audio.transcription" },
    VOICE_AND_TRANSCRIPT = { "storage.files", "audio.files", "audio.transcription" },
}
local MODE_REQUESTS = {
    VOICE = { voice = true, transcript = false },
    TRANSCRIPT = { voice = false, transcript = true },
    VOICE_AND_TRANSCRIPT = { voice = true, transcript = true },
}

local output_mode = nil

-- ---------------------------------------------------------------------------
-- Small validation helpers.
-- ---------------------------------------------------------------------------

local function application_failure(code, detail)
    return { error = { code = code, detail = detail } }
end

local function is_int(value)
    return type(value) == "number" and math.type(value) == "integer"
end

local function is_string(value)
    return type(value) == "string"
end

local function is_bool(value)
    return type(value) == "boolean"
end

local function exact_keys(value, required)
    if type(value) ~= "table" then
        return false
    end
    for key in pairs(value) do
        if not required[key] then
            return false
        end
    end
    for key in pairs(required) do
        if value[key] == nil then
            return false
        end
    end
    return true
end

local function shallow_copy(value)
    local copy = {}
    for key, item in pairs(value) do
        copy[key] = item
    end
    return copy
end

local function journal_log(level, payload)
    local fn = log[level]
    if type(fn) == "function" then
        fn(payload)
    end
end

local function is_stop_error(err)
    return err ~= nil and STOP_ERRORS[err.error] == true
end

-- ---------------------------------------------------------------------------
-- Authoritative naming derived from the capture timestamp.
-- ---------------------------------------------------------------------------

local function format_offset(minutes)
    if minutes == 0 then
        return "Z"
    end
    local sign = minutes > 0 and "+" or "-"
    local abs = math.abs(minutes)
    return string.format("%s%02d%02d", sign, abs // 60, abs % 60)
end

local function day_label(t)
    return string.format("%04d-%02d-%02d", t.year, t.month, t.day)
end

local function derive_entry_id(t)
    return string.format(
        "journal-entry-%04d-%02d-%02d_%02d-%02d-%02d-%03d%s",
        t.year, t.month, t.day, t.hour, t.minute, t.second, t.millisecond,
        format_offset(t.utc_offset_minutes)
    )
end

local function day_dir_path(t)
    return string.format("%04d/%04d-%02d/%s", t.year, t.year, t.month, day_label(t))
end

local function entry_dir_path(t)
    return day_dir_path(t) .. "/entries/" .. derive_entry_id(t)
end

local function states_dir_of(edir)
    return edir .. "/states"
end

local function capture_path_of(edir)
    return edir .. "/capture.wav"
end

local function ogg_path_of(edir)
    return edir .. "/recording.ogg"
end

local function snapshot_path_of(edir, sequence)
    return edir .. "/states/" .. string.format("state-%06d.json", sequence)
end

local function markdown_path_of(ddir, dlabel)
    return ddir .. "/journal-day-" .. dlabel .. ".md"
end

local function looks_like_entry_id(name)
    if type(name) ~= "string" then
        return false
    end
    local date_part, _, offset = name:match("^journal%-entry%-(%d%d%d%d%-%d%d%-%d%d)_(%d%d%-%d%d%-%d%d%-%d%d%d)(Z)$")
    if date_part then
        return date_part
    end
    date_part, _, offset = name:match("^journal%-entry%-(%d%d%d%d%-%d%d%-%d%d)_(%d%d%-%d%d%-%d%d%-%d%d%d)([+-]%d%d%d%d)$")
    if date_part and offset then
        return date_part
    end
    return false
end

-- ---------------------------------------------------------------------------
-- Snapshot schema construction and strict validation.
-- ---------------------------------------------------------------------------

local function initial_derivative_state(requested)
    return { state = requested and "pending" or "skipped", attempts = 0 }
end

local function build_snapshot(ctx, sequence)
    return {
        schema_version = SCHEMA_VERSION,
        sequence = sequence,
        entry_id = ctx.entry_id,
        captured_at = ctx.captured_at,
        channel_instance_id = ctx.instance_id,
        session_id = ctx.session_id,
        requested_outputs = ctx.requested_outputs,
        capture = ctx.current.capture,
        voice = ctx.current.voice,
        transcript = ctx.current.transcript,
    }
end

local function validate_captured_at(t)
    if not exact_keys(t, {
        unix_ms = true, year = true, month = true, day = true, hour = true,
        minute = true, second = true, millisecond = true, utc_offset_minutes = true,
    }) then
        return false
    end
    if not (is_int(t.unix_ms) and t.unix_ms >= 0) then return false end
    if not (is_int(t.year) and t.year >= 0 and t.year <= 9999) then return false end
    if not (is_int(t.month) and t.month >= 1 and t.month <= 12) then return false end
    if not (is_int(t.day) and t.day >= 1 and t.day <= 31) then return false end
    if not (is_int(t.hour) and t.hour >= 0 and t.hour <= 23) then return false end
    if not (is_int(t.minute) and t.minute >= 0 and t.minute <= 59) then return false end
    if not (is_int(t.second) and t.second >= 0 and t.second <= 59) then return false end
    if not (is_int(t.millisecond) and t.millisecond >= 0 and t.millisecond <= 999) then return false end
    if not (is_int(t.utc_offset_minutes) and math.abs(t.utc_offset_minutes) <= 1440) then return false end
    return true
end

local CAPTURE_KEYS_BY_STATE = {
    recording = { state = true },
    finished = { state = true, path = true, sample_rate = true, channels = true, duration_ms = true, bytes = true },
    deleted = { state = true },
    failed = { state = true, error = true },
    abandoned = { state = true },
}

local function validate_capture(capture)
    if type(capture) ~= "table" or not is_string(capture.state) or not CAPTURE_STATES[capture.state] then
        return false
    end
    if not exact_keys(capture, CAPTURE_KEYS_BY_STATE[capture.state]) then
        return false
    end
    if capture.state == "finished" then
        if capture.path ~= "capture.wav" then return false end
        if not (is_int(capture.sample_rate) and capture.sample_rate > 0) then return false end
        if not (is_int(capture.channels) and capture.channels > 0) then return false end
        if not (is_int(capture.duration_ms) and capture.duration_ms >= 0) then return false end
        if not (is_int(capture.bytes) and capture.bytes >= 0) then return false end
    elseif capture.state == "failed" then
        if not (is_string(capture.error) and capture.error ~= "") then return false end
    end
    return true
end

local function validate_derivative(derivative, kind)
    if type(derivative) ~= "table" then
        return false
    end
    if not is_string(derivative.state) or not DERIVATIVE_STATES[derivative.state] then
        return false
    end
    if not is_int(derivative.attempts) or derivative.attempts < 0 then
        return false
    end
    local state = derivative.state
    if state == "finished" then
        if kind == "voice" then
            if not exact_keys(derivative, { state = true, attempts = true, path = true }) then return false end
            if derivative.path ~= "recording.ogg" then return false end
        else
            if not exact_keys(derivative, { state = true, attempts = true, text = true }) then return false end
            if not is_string(derivative.text) or #derivative.text > MAX_TRANSCRIPT_BYTES then return false end
        end
    elseif state == "failed" then
        if not exact_keys(derivative, { state = true, attempts = true, error = true }) then return false end
        if not is_string(derivative.error) or derivative.error == "" then return false end
    else
        if not exact_keys(derivative, { state = true, attempts = true }) then return false end
    end
    return true
end

local SNAPSHOT_KEYS = {
    schema_version = true,
    sequence = true,
    entry_id = true,
    captured_at = true,
    channel_instance_id = true,
    session_id = true,
    requested_outputs = true,
    capture = true,
    voice = true,
    transcript = true,
}

local function validate_snapshot(doc, expected_sequence, expected_entry_id)
    if not exact_keys(doc, SNAPSHOT_KEYS) then
        return false
    end
    if doc.schema_version ~= SCHEMA_VERSION or math.type(doc.schema_version) ~= "integer" then
        return false
    end
    if not is_int(doc.sequence) or doc.sequence ~= expected_sequence then
        return false
    end
    if not is_string(doc.entry_id) or doc.entry_id ~= expected_entry_id then
        return false
    end
    if not validate_captured_at(doc.captured_at) then
        return false
    end
    -- The entry identity is derived from the authoritative timestamp; a
    -- snapshot whose identity does not match its timestamp is malformed.
    if derive_entry_id(doc.captured_at) ~= doc.entry_id then
        return false
    end
    if not is_string(doc.channel_instance_id) or doc.channel_instance_id == "" then
        return false
    end
    if not is_string(doc.session_id) or doc.session_id == "" then
        return false
    end
    if not exact_keys(doc.requested_outputs, { voice = true, transcript = true }) then
        return false
    end
    if not is_bool(doc.requested_outputs.voice) or not is_bool(doc.requested_outputs.transcript) then
        return false
    end
    if not validate_capture(doc.capture) then
        return false
    end
    if not validate_derivative(doc.voice, "voice") then
        return false
    end
    if not validate_derivative(doc.transcript, "transcript") then
        return false
    end
    return true
end

-- ---------------------------------------------------------------------------
-- Filesystem operations over the mounted output tree.
-- ---------------------------------------------------------------------------

local function list_directory(mount, path)
    local items = {}
    local cursor = nil
    for _ = 1, LIST_MAX_PAGES do
        local opts = { limit = LIST_PAGE_LIMIT }
        if cursor ~= nil then
            opts.cursor = cursor
        end
        local page, err = fs.list(mount, path, opts)
        if page == nil then
            return nil, err
        end
        for _, item in ipairs(page.entries) do
            items[#items + 1] = item
        end
        if page.next_cursor == nil then
            break
        end
        cursor = page.next_cursor
    end
    table.sort(items, function(a, b)
        if a.name == b.name then
            return a.kind < b.kind
        end
        return a.name < b.name
    end)
    return items
end

local function load_chain(mount, edir, entry_id)
    local chain = {}
    for sequence = 0, MAX_SNAPSHOTS_PER_ENTRY - 1 do
        local res, err = fs.read_text(mount, snapshot_path_of(edir, sequence), { max_bytes = SNAPSHOT_READ_MAX })
        if res == nil then
            local code = err and err.error
            if code == "E_NOT_FOUND" or code == "E_TOO_LARGE" then
                break
            end
            return nil, err
        end
        local doc = json.decode(res.text, DECODE_LIMITS)
        if type(doc) ~= "table" or not validate_snapshot(doc, sequence, entry_id) then
            break
        end
        chain[#chain + 1] = doc
    end
    return chain
end

local function append_snapshot(mount, ctx)
    local sequence = ctx.last_sequence + 1
    if sequence > MAX_SEQUENCE then
        return nil, { error = "E_BUSY", reason = "snapshot sequence exhausted" }
    end
    local text, encode_err = json.encode(build_snapshot(ctx, sequence), ENCODE_LIMITS)
    if text == nil then
        return nil, { error = "E_HOST_FAILURE", reason = "snapshot encoding failed" }
    end
    local res, write_err = fs.write_text(mount, snapshot_path_of(ctx.edir, sequence), text, { mode = "create-new" })
    if res == nil then
        return nil, write_err
    end
    ctx.last_sequence = sequence
    return true
end

local function remove_best_effort(mount, path)
    local res = fs.remove(mount, path, { missing_ok = true })
    return res ~= nil
end

-- ---------------------------------------------------------------------------
-- Markdown projection (nonauthoritative, replaceable).
-- ---------------------------------------------------------------------------

local function render_markdown(dlabel, latest_snapshots)
    local parts = { "# Journal " .. dlabel .. "\n\n" }
    for _, doc in ipairs(latest_snapshots) do
        local t = doc.captured_at
        parts[#parts + 1] = string.format("## Entry %02d-%02d-%02d\n\n", t.hour, t.minute, t.second)
        if doc.requested_outputs.transcript then
            local tr = doc.transcript
            if tr.state == "finished" then
                if is_string(tr.text) and tr.text ~= "" then
                    parts[#parts + 1] = tr.text .. "\n\n"
                end
            elseif tr.state == "failed" then
                parts[#parts + 1] = "[Transcription failed: " .. (tr.error or "unknown error") .. "]\n\n"
            elseif tr.state == "pending" or tr.state == "running" then
                parts[#parts + 1] = "[Transcription pending]\n\n"
            end
        end
        if doc.requested_outputs.voice and doc.voice.state == "finished" then
            parts[#parts + 1] = "[Source recording](entries/" .. doc.entry_id .. "/" .. doc.voice.path .. ")\n\n"
        end
    end
    return table.concat(parts)
end

local function collect_day_entries(mount, ddir, dlabel)
    local entries, err = list_directory(mount, ddir .. "/entries")
    if entries == nil then
        if err and err.error == "E_NOT_FOUND" then
            return {}
        end
        return nil, err
    end
    local latest_snapshots = {}
    for _, item in ipairs(entries) do
        if item.kind == "directory" then
            local date_part = looks_like_entry_id(item.name)
            if date_part == dlabel then
                local edir = ddir .. "/entries/" .. item.name
                local chain, chain_err = load_chain(mount, edir, item.name)
                if chain == nil then
                    return nil, chain_err
                end
                local latest = chain[#chain]
                if latest ~= nil and (latest.capture.state == "finished" or latest.capture.state == "deleted") then
                    latest_snapshots[#latest_snapshots + 1] = latest
                end
            end
        end
    end
    table.sort(latest_snapshots, function(a, b)
        if a.captured_at.unix_ms == b.captured_at.unix_ms then
            return a.entry_id < b.entry_id
        end
        return a.captured_at.unix_ms < b.captured_at.unix_ms
    end)
    return latest_snapshots
end

local function regenerate_day(mount, ddir, dlabel)
    local latest_snapshots, err = collect_day_entries(mount, ddir, dlabel)
    if latest_snapshots == nil then
        return nil, err
    end
    local md_path = markdown_path_of(ddir, dlabel)
    if #latest_snapshots == 0 then
        local res, rem_err = fs.remove(mount, md_path, { missing_ok = true })
        if res == nil then
            return nil, rem_err
        end
        return true
    end
    local text = render_markdown(dlabel, latest_snapshots)
    local current, read_err = fs.read_text(mount, md_path, { max_bytes = MARKDOWN_READ_MAX })
    if current ~= nil then
        if current.text == text then
            return true
        end
    else
        local code = read_err and read_err.error
        if code ~= "E_NOT_FOUND" and code ~= "E_TOO_LARGE" then
            return nil, read_err
        end
    end
    local res, write_err = fs.write_text(mount, md_path, text, { mode = "replace" })
    if res == nil then
        return nil, write_err
    end
    return true
end

-- ---------------------------------------------------------------------------
-- Derivation: voice (OGG), transcript, spool cleanup, day projection.
-- ---------------------------------------------------------------------------

local function mark_pending_failed(ctx, derivative_key, code)
    local derivative = ctx.current[derivative_key]
    ctx.current[derivative_key] = {
        state = "failed",
        attempts = derivative.attempts + 1,
        error = code,
    }
end

local function all_requested_finished(ctx)
    local requested = ctx.requested_outputs
    if requested.voice and ctx.current.voice.state ~= "finished" then
        return false
    end
    if requested.transcript and ctx.current.transcript.state ~= "finished" then
        return false
    end
    return true
end

local function cleanup_spool(mount, ctx)
    if ctx.current.capture.state ~= "finished" or not all_requested_finished(ctx) then
        return true
    end
    local res, err = fs.remove(mount, ctx.capture_path, { missing_ok = true })
    if res == nil then
        if is_stop_error(err) then
            return nil, err
        end
        journal_log("warn", {
            message = "journal_spool_cleanup_deferred",
            entry_id = ctx.entry_id,
            error = err and err.error or "E_HOST_FAILURE",
        })
        return true
    end
    ctx.current.capture = { state = "deleted" }
    local ok, snap_err = append_snapshot(mount, ctx)
    if not ok then
        return nil, snap_err
    end
    journal_log("info", {
        message = "journal_spool_cleaned",
        entry_id = ctx.entry_id,
        sequence = ctx.last_sequence,
    })
    return true
end

local function open_capture_recording(mount, ctx)
    local rec, err = audio.open(mount, ctx.capture_path, { format = "wav-pcm-s16le" })
    if rec ~= nil then
        return rec
    end
    return nil, err
end

local function derive_voice(mount, ctx, rec)
    local voice = ctx.current.voice
    voice = { state = "running", attempts = voice.attempts + 1 }
    ctx.current.voice = voice
    local ok, snap_err = append_snapshot(mount, ctx)
    if not ok then
        return nil, snap_err
    end
    local res, err = audio.export(rec, mount, ctx.ogg_path, { format = "ogg-vorbis" })
    if res ~= nil then
        ctx.current.voice = { state = "finished", attempts = voice.attempts, path = "recording.ogg" }
    else
        if is_stop_error(err) then
            return nil, err
        end
        remove_best_effort(mount, ctx.ogg_path)
        ctx.current.voice = { state = "failed", attempts = voice.attempts, error = err and err.error or "E_HOST_FAILURE" }
        journal_log("warn", {
            message = "journal_derivative_failed",
            entry_id = ctx.entry_id,
            derivative = "voice",
            error = ctx.current.voice.error,
            attempts = voice.attempts,
        })
    end
    return append_snapshot(mount, ctx)
end

local function bounded_transcript_text(result)
    if type(result) ~= "table" or not is_string(result.text) then
        return nil, "E_INVALID_VALUE"
    end
    if #result.text > MAX_TRANSCRIPT_BYTES then
        return nil, "E_TOO_LARGE"
    end
    if utf8.len(result.text) == nil then
        return nil, "E_INVALID_VALUE"
    end
    return result.text
end

local function derive_transcript(mount, ctx, rec)
    local transcript = ctx.current.transcript
    transcript = { state = "running", attempts = transcript.attempts + 1 }
    ctx.current.transcript = transcript
    local ok, snap_err = append_snapshot(mount, ctx)
    if not ok then
        return nil, snap_err
    end
    local result, err = transcription.transcribe(rec)
    if result ~= nil then
        local text, text_err = bounded_transcript_text(result)
        if text ~= nil then
            ctx.current.transcript = { state = "finished", attempts = transcript.attempts, text = text }
        else
            ctx.current.transcript = { state = "failed", attempts = transcript.attempts, error = text_err }
        end
    else
        if is_stop_error(err) then
            return nil, err
        end
        ctx.current.transcript = { state = "failed", attempts = transcript.attempts, error = err and err.error or "E_HOST_FAILURE" }
    end
    if ctx.current.transcript.state == "failed" then
        journal_log("warn", {
            message = "journal_derivative_failed",
            entry_id = ctx.entry_id,
            derivative = "transcript",
            error = ctx.current.transcript.error,
            attempts = transcript.attempts,
        })
    end
    return append_snapshot(mount, ctx)
end

-- Complete pending derivatives for one entry. Returns true, or (nil, err)
-- when a stop error requires immediate termination. When opts.skip_markdown
-- is set the caller regenerates day projections itself (recovery does this
-- once per day after every entry is processed).
local function derive_entry(mount, ctx, opts)
    opts = opts or {}
    local requested = ctx.requested_outputs
    local voice_pending = requested.voice and ctx.current.voice.state == "pending"
    local transcript_pending = requested.transcript and ctx.current.transcript.state == "pending"
    local rec = nil
    if voice_pending or transcript_pending then
        local open_err
        rec, open_err = open_capture_recording(mount, ctx)
        if rec == nil then
            if is_stop_error(open_err) then
                return nil, open_err
            end
            local code = open_err and open_err.error or "E_HOST_FAILURE"
            if voice_pending then
                mark_pending_failed(ctx, "voice", code)
            end
            if transcript_pending then
                mark_pending_failed(ctx, "transcript", code)
            end
            local ok, snap_err = append_snapshot(mount, ctx)
            if not ok then
                return nil, snap_err
            end
            journal_log("warn", {
                message = "journal_spool_open_failed",
                entry_id = ctx.entry_id,
                error = code,
            })
        end
    end
    if rec ~= nil and requested.voice and ctx.current.voice.state == "pending" then
        local ok, err = derive_voice(mount, ctx, rec)
        if not ok then
            return nil, err
        end
    end
    if rec ~= nil and requested.transcript and ctx.current.transcript.state == "pending" then
        local ok, err = derive_transcript(mount, ctx, rec)
        if not ok then
            return nil, err
        end
    end
    local ok, err = cleanup_spool(mount, ctx)
    if not ok then
        return nil, err
    end
    if not opts.skip_markdown then
        local dok, derr = regenerate_day(mount, ctx.ddir, ctx.dlabel)
        if not dok then
            return nil, derr
        end
    end
    return true
end

local function context_from_snapshot(latest, ddir, dlabel)
    local edir = ddir .. "/entries/" .. latest.entry_id
    return {
        entry_id = latest.entry_id,
        captured_at = latest.captured_at,
        instance_id = latest.channel_instance_id,
        session_id = latest.session_id,
        requested_outputs = latest.requested_outputs,
        current = {
            capture = shallow_copy(latest.capture),
            voice = shallow_copy(latest.voice),
            transcript = shallow_copy(latest.transcript),
        },
        last_sequence = latest.sequence,
        ddir = ddir,
        dlabel = dlabel,
        edir = edir,
        states_dir = states_dir_of(edir),
        capture_path = capture_path_of(edir),
        ogg_path = ogg_path_of(edir),
    }
end

-- ---------------------------------------------------------------------------
-- Startup recovery (managed task).
-- ---------------------------------------------------------------------------

local function charge(budget)
    budget.ops = budget.ops - 1
    if budget.ops <= 0 then
        budget.exhausted = true
    end
    return not budget.exhausted
end

local function note_stop(budget, err)
    if is_stop_error(err) then
        budget.stopped = true
    end
end

local function clean_orphan_entry(mount, edir, budget)
    remove_best_effort(mount, capture_path_of(edir))
    if not charge(budget) then return end
    remove_best_effort(mount, ogg_path_of(edir))
    if not charge(budget) then return end
    local items, err = list_directory(mount, states_dir_of(edir))
    if items ~= nil then
        for _, item in ipairs(items) do
            if item.kind == "file" then
                remove_best_effort(mount, states_dir_of(edir) .. "/" .. item.name)
                if not charge(budget) then return end
            end
        end
        remove_best_effort(mount, states_dir_of(edir))
        if not charge(budget) then return end
    elseif is_stop_error(err) then
        budget.stopped = true
        return
    end
    remove_best_effort(mount, edir)
    charge(budget)
end

local function recover_entry(mount, ddir, dlabel, name, budget)
    local edir = ddir .. "/entries/" .. name
    if looks_like_entry_id(name) ~= dlabel then
        clean_orphan_entry(mount, edir, budget)
        return
    end
    local chain, err = load_chain(mount, edir, name)
    if not charge(budget) then
        return
    end
    if chain == nil then
        note_stop(budget, err)
        if not budget.stopped then
            journal_log("warn", {
                message = "journal_recovery_entry_unreadable",
                entry_id = name,
                error = err and err.error or "E_HOST_FAILURE",
            })
        end
        return
    end
    if #chain == 0 then
        clean_orphan_entry(mount, edir, budget)
        return
    end
    local latest = chain[#chain]
    local ctx = context_from_snapshot(latest, ddir, dlabel)
    local state = latest.capture.state
    if state == "recording" then
        local stat = fs.stat(mount, ctx.capture_path)
        if not charge(budget) then return end
        local has_partial_wav = stat ~= nil and stat.kind == "file" and (stat.size or 0) > WAV_HEADER_BYTES
        if has_partial_wav then
            ctx.current.capture = { state = "failed", error = "abandoned" }
        else
            ctx.current.capture = { state = "abandoned" }
        end
        local ok, snap_err = append_snapshot(mount, ctx)
        if not ok then
            note_stop(budget, snap_err)
            return
        end
        remove_best_effort(mount, ctx.capture_path)
        charge(budget)
        journal_log("warn", {
            message = "journal_recovery_capture_classified",
            entry_id = ctx.entry_id,
            capture_state = ctx.current.capture.state,
            sequence = ctx.last_sequence,
        })
        return
    end
    if state == "failed" or state == "abandoned" then
        remove_best_effort(mount, ctx.capture_path)
        charge(budget)
        return
    end
    if state == "finished" or state == "deleted" then
        local reset = false
        local requested = ctx.requested_outputs
        if requested.voice then
            local voice_state = ctx.current.voice.state
            if voice_state == "running" or voice_state == "failed" then
                ctx.current.voice = { state = "pending", attempts = ctx.current.voice.attempts }
                reset = true
            end
        end
        if requested.transcript then
            local transcript_state = ctx.current.transcript.state
            if transcript_state == "running" or transcript_state == "failed" then
                ctx.current.transcript = { state = "pending", attempts = ctx.current.transcript.attempts }
                reset = true
            end
        end
        if reset then
            local ok, snap_err = append_snapshot(mount, ctx)
            if not ok then
                note_stop(budget, snap_err)
                return
            end
            journal_log("info", {
                message = "journal_recovery_derivative_reset",
                entry_id = ctx.entry_id,
                sequence = ctx.last_sequence,
            })
        end
        local needs_work = (requested.voice and ctx.current.voice.state == "pending")
            or (requested.transcript and ctx.current.transcript.state == "pending")
        if needs_work then
            local stat, stat_err = fs.stat(mount, ctx.capture_path)
            if not charge(budget) then return end
            if is_stop_error(stat_err) then
                budget.stopped = true
                return
            end
            local wav_present = stat ~= nil and stat.kind == "file"
            if not wav_present then
                local marked = false
                if requested.voice and ctx.current.voice.state == "pending" then
                    mark_pending_failed(ctx, "voice", "E_NOT_FOUND")
                    marked = true
                end
                if requested.transcript and ctx.current.transcript.state == "pending" then
                    mark_pending_failed(ctx, "transcript", "E_NOT_FOUND")
                    marked = true
                end
                if marked then
                    local ok, snap_err = append_snapshot(mount, ctx)
                    if not ok then
                        note_stop(budget, snap_err)
                    end
                end
                return
            end
            local ok, derive_err = derive_entry(mount, ctx, { skip_markdown = true })
            if not ok then
                note_stop(budget, derive_err)
                if not budget.stopped then
                    journal_log("warn", {
                        message = "journal_recovery_derive_failed",
                        entry_id = ctx.entry_id,
                        error = derive_err and derive_err.error or "E_HOST_FAILURE",
                    })
                end
            end
            return
        end
        -- All requested derivatives are terminal; retry spool cleanup when a
        -- finished capture still owns the WAV (interrupted cleanup).
        if ctx.current.capture.state == "finished" then
            local ok, clean_err = cleanup_spool(mount, ctx)
            if not ok then
                note_stop(budget, clean_err)
            end
        end
    end
end

local function recover_day(mount, ddir, dlabel, budget)
    local entries, err = list_directory(mount, ddir .. "/entries")
    if not charge(budget) then
        return
    end
    if entries ~= nil then
        for _, item in ipairs(entries) do
            if item.kind == "directory" then
                recover_entry(mount, ddir, dlabel, item.name, budget)
                if budget.stopped or budget.exhausted then
                    return
                end
            end
        end
    elseif is_stop_error(err) then
        budget.stopped = true
        return
    end
    local ok, regen_err = regenerate_day(mount, ddir, dlabel)
    charge(budget)
    if not ok then
        note_stop(budget, regen_err)
        if not budget.stopped then
            journal_log("warn", {
                message = "journal_recovery_markdown_failed",
                day = dlabel,
                error = regen_err and regen_err.error or "E_HOST_FAILURE",
            })
        end
    end
end

local function recover()
    local budget = { ops = RECOVERY_OP_BUDGET, stopped = false, exhausted = false }
    local mount, mount_err = fs.mount("output")
    if mount == nil then
        journal_log("warn", {
            message = "journal_recovery_mount_unavailable",
            error = mount_err and mount_err.error or "E_HOST_FAILURE",
        })
        return
    end
    local years, year_err = list_directory(mount, "")
    if years == nil then
        if year_err and year_err.error ~= "E_NOT_FOUND" then
            journal_log("warn", {
                message = "journal_recovery_root_unreadable",
                error = year_err.error,
            })
        end
        return
    end
    for _, year in ipairs(years) do
        if year.kind == "directory" and year.name:match("^%d%d%d%d$") then
            local months, month_err = list_directory(mount, year.name)
            if months == nil or not charge(budget) then
                if months == nil then
                    note_stop(budget, month_err)
                end
                break
            end
            for _, month in ipairs(months) do
                if month.kind == "directory" and month.name:match("^%d%d%d%d%-%d%d$") then
                    local month_path = year.name .. "/" .. month.name
                    local days, day_err = list_directory(mount, month_path)
                    if days == nil or not charge(budget) then
                        if days == nil then
                            note_stop(budget, day_err)
                        end
                        break
                    end
                    for _, day in ipairs(days) do
                        if day.kind == "directory" and day.name:match("^%d%d%d%d%-%d%d%-%d%d$") then
                            recover_day(mount, month_path .. "/" .. day.name, day.name, budget)
                            if budget.stopped or budget.exhausted then
                                break
                            end
                        end
                    end
                end
                if budget.stopped or budget.exhausted then
                    break
                end
            end
        end
        if budget.stopped or budget.exhausted then
            break
        end
    end
    if budget.exhausted then
        journal_log("warn", { message = "journal_recovery_budget_exhausted" })
    end
end

-- ---------------------------------------------------------------------------
-- Callbacks.
-- ---------------------------------------------------------------------------

local function startup(configuration)
    if type(configuration) ~= "table" or not exact_keys(configuration, { schema_version = true, values = true }) then
        return application_failure("E_INVALID_ARGUMENT", "invalid configuration")
    end
    if configuration.schema_version ~= 1 or type(configuration.values) ~= "table" then
        return application_failure("E_INVALID_ARGUMENT", "invalid configuration")
    end
    if not exact_keys(configuration.values, { output_mode = true }) then
        return application_failure("E_INVALID_ARGUMENT", "invalid configuration")
    end
    local configured = configuration.values.output_mode
    if type(configured) ~= "string" or not OUTPUT_MODES[configured] then
        return application_failure("E_INVALID_ARGUMENT", "invalid output mode")
    end
    output_mode = configured
    local ok, err = runtime.spawn(recover)
    if not ok then
        journal_log("warn", {
            message = "journal_recovery_not_admitted",
            error = err and err.error or "E_HOST_FAILURE",
        })
    end
end

local function handle_readiness(context)
    if output_mode == nil or type(context) ~= "table" then
        return { ready = false, status = output_mode or "" }
    end
    if type(context.capabilities) ~= "table" then
        return { ready = false, status = output_mode }
    end
    for _, capability in ipairs(MODE_CAPABILITIES[output_mode]) do
        if context.capabilities[capability] ~= "available" then
            return { ready = false, status = output_mode }
        end
    end
    local resources = context.resources
    if type(resources) ~= "table" or type(resources.mounts) ~= "table" then
        return { ready = false, status = output_mode }
    end
    if resources.mounts.output ~= "available" then
        return { ready = false, status = output_mode }
    end
    return { ready = true, status = output_mode }
end

local function validate_captured_at_input(local_time)
    if not exact_keys(local_time, {
        year = true, month = true, day = true, hour = true,
        minute = true, second = true, millisecond = true, utc_offset_minutes = true,
    }) then
        return false
    end
    if not (is_int(local_time.year) and local_time.year >= 0 and local_time.year <= 9999) then return false end
    if not (is_int(local_time.month) and local_time.month >= 1 and local_time.month <= 12) then return false end
    if not (is_int(local_time.day) and local_time.day >= 1 and local_time.day <= 31) then return false end
    if not (is_int(local_time.hour) and local_time.hour >= 0 and local_time.hour <= 23) then return false end
    if not (is_int(local_time.minute) and local_time.minute >= 0 and local_time.minute <= 59) then return false end
    if not (is_int(local_time.second) and local_time.second >= 0 and local_time.second <= 59) then return false end
    if not (is_int(local_time.millisecond) and local_time.millisecond >= 0 and local_time.millisecond <= 999) then return false end
    if not (is_int(local_time.utc_offset_minutes) and math.abs(local_time.utc_offset_minutes) <= 1440) then return false end
    return true
end

local function build_input_context(event, instance_id, mode)
    if type(event) ~= "table" then
        return nil, "invalid capture event"
    end
    if event.event ~= channel.CAPTURE_COMPLETE then
        return nil, "unsupported event type"
    end
    if type(event.audio) ~= "userdata" then
        return nil, "capture audio is missing"
    end
    if not is_string(event.session) or event.session == "" or #event.session > MAX_SESSION_BYTES then
        return nil, "capture session identity is invalid"
    end
    if not exact_keys(event.timestamp, { unix_ms = true }) then
        return nil, "capture timestamp is invalid"
    end
    if not is_int(event.timestamp.unix_ms) or event.timestamp.unix_ms < 0 then
        return nil, "capture timestamp is invalid"
    end
    if not validate_captured_at_input(event.local_time) then
        return nil, "capture local time is invalid"
    end
    local captured_at = {
        unix_ms = event.timestamp.unix_ms,
        year = event.local_time.year,
        month = event.local_time.month,
        day = event.local_time.day,
        hour = event.local_time.hour,
        minute = event.local_time.minute,
        second = event.local_time.second,
        millisecond = event.local_time.millisecond,
        utc_offset_minutes = event.local_time.utc_offset_minutes,
    }
    local requests = MODE_REQUESTS[mode]
    local edir = entry_dir_path(captured_at)
    return {
        entry_id = derive_entry_id(captured_at),
        captured_at = captured_at,
        instance_id = instance_id,
        session_id = event.session,
        requested_outputs = { voice = requests.voice, transcript = requests.transcript },
        current = {
            capture = { state = "recording" },
            voice = initial_derivative_state(requests.voice),
            transcript = initial_derivative_state(requests.transcript),
        },
        last_sequence = -1,
        ddir = day_dir_path(captured_at),
        dlabel = day_label(captured_at),
        edir = edir,
        states_dir = states_dir_of(edir),
        capture_path = capture_path_of(edir),
        ogg_path = ogg_path_of(edir),
    }
end

local function commit_failure(err)
    local code = err and err.error or "E_HOST_FAILURE"
    if STOP_ERRORS[code] then
        return application_failure(code, "capture commit interrupted")
    end
    return application_failure("E_CAPTURE_FAILURE", "capture commit failed")
end

local function deferred_derive(ctx)
    local mount, mount_err = fs.mount("output")
    if mount == nil then
        journal_log("warn", {
            message = "journal_deferred_mount_unavailable",
            entry_id = ctx.entry_id,
            error = mount_err and mount_err.error or "E_HOST_FAILURE",
        })
        return
    end
    local ok, err = derive_entry(mount, ctx)
    if ok == nil and not is_stop_error(err) then
        journal_log("warn", {
            message = "journal_deferred_failed",
            entry_id = ctx.entry_id,
            error = err and err.error or "E_HOST_FAILURE",
        })
    end
end

local function handle_input(event)
    if output_mode == nil then
        return application_failure("E_INVALID_ARGUMENT", "output mode is not configured")
    end
    local instance_id = runtime.INSTANCE_ID
    if not is_string(instance_id) or instance_id == "" then
        return application_failure("E_CAPTURE_FAILURE", "channel instance identity is unavailable")
    end
    local ctx, validation_detail = build_input_context(event, instance_id, output_mode)
    if ctx == nil then
        return application_failure("E_INVALID_ARGUMENT", validation_detail)
    end
    local mount, mount_err = fs.mount("output")
    if mount == nil then
        return application_failure("E_CAPTURE_FAILURE", "output mount is unavailable")
    end
    local res, err = fs.mkdir(mount, ctx.edir, { parents = true })
    if res == nil then
        return commit_failure(err)
    end
    res, err = fs.mkdir(mount, ctx.states_dir, { parents = false })
    if res == nil then
        return commit_failure(err)
    end
    local ok, snap_err = append_snapshot(mount, ctx)
    if not ok then
        return commit_failure(snap_err)
    end
    local export, export_err = audio.export(event.audio, mount, ctx.capture_path, { format = "wav-pcm-s16le" })
    if export == nil then
        local code = export_err and export_err.error or "E_HOST_FAILURE"
        if not STOP_ERRORS[code] then
            ctx.current.capture = { state = "failed", error = code }
            append_snapshot(mount, ctx)
        end
        return commit_failure(export_err)
    end
    if not (is_int(export.sample_rate) and is_int(export.channels)
        and is_int(export.duration_ms) and is_int(export.bytes)) then
        ctx.current.capture = { state = "failed", error = "E_HOST_FAILURE" }
        append_snapshot(mount, ctx)
        return application_failure("E_CAPTURE_FAILURE", "capture export metadata is invalid")
    end
    ctx.current.capture = {
        state = "finished",
        path = "capture.wav",
        sample_rate = export.sample_rate,
        channels = export.channels,
        duration_ms = export.duration_ms,
        bytes = export.bytes,
    }
    ok, snap_err = append_snapshot(mount, ctx)
    if not ok then
        return commit_failure(snap_err)
    end
    journal_log("info", {
        message = "journal_capture_committed",
        entry_id = ctx.entry_id,
        sequence = ctx.last_sequence,
        mode = output_mode,
    })
    local defer_ok, defer_err = runtime.defer(function()
        deferred_derive(ctx)
    end)
    if defer_ok then
        return { ok = true }
    end
    if defer_err and defer_err.error == "E_BUSY" then
        -- Defer capacity is exhausted: complete derivation inline on this
        -- input execution instead of reporting an unadmitted deferred task.
        local inline_ok, inline_err = derive_entry(mount, ctx)
        if inline_ok == nil and is_stop_error(inline_err) then
            return application_failure(inline_err.error, "capture committed; derivation interrupted")
        end
        return { ok = true }
    end
    -- The durable capture commit remains recoverable by the next startup.
    return application_failure("E_CAPTURE_FAILURE", "deferred derivation was not admitted")
end

return {
    startup = startup,
    handle_readiness = handle_readiness,
    handle_input = handle_input,
}
