-- Keyboard Channel: portable keyboard output implementation in pure Lua.
--
-- Owns Keyboard-specific policy entirely in Lua:
--   * detached configuration validation (three scalar hierarchy selections);
--   * readiness reference/capability checks (every reference required) with
--     recoverable preparation;
--   * deliberate exclusion of audio.transcription from admission readiness;
--   * input transcription over opaque recording userdata;
--   * empty/malformed transcript rejection;
--   * one trailing ASCII space only when absent;
--   * delivery success only for status="delivered";
--   * no replay for any terminal outcome;
--   * SOS validation and one semantic Enter operation.
--
-- The package uses subspace.transcription, subspace.keyboard_output, and
-- subspace.channel only. It does not inspect Sleepwalker state, own shared
-- transport, retain audio beyond the input owner, or know internal capability
-- types. No transcript text, semantic key, or logical profile ever enters a
-- log payload or error detail.
local channel = require("subspace.channel")
local transcription = require("subspace.transcription")
local keyboard_output = require("subspace.keyboard_output")
local log = require("subspace.log")

local MAX_SCALAR_BYTES = 256
local MAX_TEXT_BYTES = 65536
local KEYBOARD_CAPABILITY = "keyboard.output"
local OS_FIELD = "host_os"
local LAYOUT_FIELD = "host_layout"
local PROFILE_FIELD = "host_profile"

-- Detached scalar configuration: the selected platform, keyboard layout, and
-- final logical host profile IDs. Only host_profile drives keyboard output;
-- the platform and layout are persisted editor selections that readiness must
-- still see resolve in their host sources.
local host_os = nil
local host_layout = nil
local host_profile = nil

-- ---------------------------------------------------------------------------
-- Small validation helpers.
-- ---------------------------------------------------------------------------

local function application_failure(code, detail)
    return { error = { code = code, detail = detail } }
end

local function is_string(value)
    return type(value) == "string"
end

-- A detached configuration scalar: a nonempty canonical UTF-8 string within
-- the shared byte bound.
local function valid_scalar(value)
    return is_string(value) and value ~= "" and #value <= MAX_SCALAR_BYTES and utf8.len(value) ~= nil
end

local function exact_keys(value, required)
    if type(value) ~= "table" then
        return false
    end
    for key in pairs(value) do
        if required[key] == nil then
            return false
        end
    end
    for key in pairs(required) do
        if value[key] == nil then
            return false
        end
    end
    return true
end

-- Bounded, content-free diagnostic. Payloads carry only a message tag and
-- normalized codes or byte lengths; never transcript text, semantic keys, or
-- logical profile IDs (design D9).
local function keyboard_log(level, payload)
    local fn = log[level]
    if type(fn) == "function" then
        fn(payload)
    end
end

-- ---------------------------------------------------------------------------
-- Startup: exact detached three-scalar configuration validation, no host
-- effect.
-- ---------------------------------------------------------------------------

local function startup(configuration)
    if not exact_keys(configuration, { schema_version = true, values = true }) then
        return application_failure("E_INVALID_ARGUMENT", "invalid configuration")
    end
    if configuration.schema_version ~= 1 or type(configuration.values) ~= "table" then
        return application_failure("E_INVALID_ARGUMENT", "invalid configuration")
    end
    if not exact_keys(configuration.values, {
        [OS_FIELD] = true,
        [LAYOUT_FIELD] = true,
        [PROFILE_FIELD] = true,
    }) then
        return application_failure("E_INVALID_ARGUMENT", "invalid configuration")
    end
    local os_id = configuration.values[OS_FIELD]
    local layout_id = configuration.values[LAYOUT_FIELD]
    local profile_id = configuration.values[PROFILE_FIELD]
    if not valid_scalar(os_id) then
        return application_failure("E_INVALID_ARGUMENT", "invalid host platform")
    end
    if not valid_scalar(layout_id) then
        return application_failure("E_INVALID_ARGUMENT", "invalid keyboard layout")
    end
    if not valid_scalar(profile_id) then
        return application_failure("E_INVALID_ARGUMENT", "invalid host profile")
    end
    host_os = os_id
    host_layout = layout_id
    host_profile = profile_id
    keyboard_log("info", {
        message = "keyboard_configured",
        os_bytes = #os_id,
        layout_bytes = #layout_id,
        profile_bytes = #profile_id,
    })
end

-- ---------------------------------------------------------------------------
-- Readiness: all three dynamic references plus keyboard.output availability.
--
-- audio.transcription is deliberately excluded from PTT admission readiness;
-- a transcription backend that is unavailable before PTT still reports ready
-- and fails later, after capture, through the normalized operation failure.
-- ---------------------------------------------------------------------------

local function handle_readiness(context)
    if host_os == nil or host_layout == nil or host_profile == nil or type(context) ~= "table" then
        return { ready = false, status = "not configured" }
    end
    -- Every required dynamic reference must resolve in its host source. When
    -- the platform, layout, or final profile is unavailable the package reports
    -- not ready without attempting keyboard preparation or output.
    local references = context.references
    if type(references) ~= "table" then
        return { ready = false, status = "references unavailable" }
    end
    if references[OS_FIELD] ~= "available" then
        return { ready = false, status = "platform unavailable" }
    end
    if references[LAYOUT_FIELD] ~= "available" then
        return { ready = false, status = "layout unavailable" }
    end
    if references[PROFILE_FIELD] ~= "available" then
        return { ready = false, status = "profile unavailable" }
    end
    local capabilities = context.capabilities
    if type(capabilities) ~= "table" then
        return { ready = false, status = "keyboard unavailable" }
    end
    local state = capabilities[KEYBOARD_CAPABILITY]
    if state == "available" then
        return { ready = true, status = "ready" }
    elseif state == "recoverable" then
        return { ready = false, status = "keyboard preparing", prepare = { KEYBOARD_CAPABILITY } }
    end
    return { ready = false, status = "keyboard unavailable" }
end

-- ---------------------------------------------------------------------------
-- Transcript validation and trailing-space policy.
-- ---------------------------------------------------------------------------

local function bounded_transcript_text(result)
    if type(result) ~= "table" or not is_string(result.text) then
        return nil, "E_INVALID_VALUE"
    end
    if result.text == "" then
        return nil, "E_EMPTY"
    end
    if #result.text > MAX_TEXT_BYTES then
        return nil, "E_TOO_LARGE"
    end
    if utf8.len(result.text) == nil then
        return nil, "E_INVALID_VALUE"
    end
    return result.text
end

-- Append exactly one ASCII space only when the nonempty transcript does not
-- already end in an ASCII space. A multibyte UTF-8 final byte is never 0x20,
-- so a byte-level suffix test is exactly "ends in ASCII space".
local function with_trailing_space(text)
    if text:sub(-1) == " " then
        return text
    end
    return text .. " "
end

-- ---------------------------------------------------------------------------
-- Delivery outcome projection.
--
-- Only status="delivered" is input/SOS success. Every other terminal semantic
-- outcome (rejected/failed/indeterminate) and every contract/ownership/
-- capacity/closed/stale error pair maps to one bounded application failure
-- carrying a stable code and a content-free detail. No transcript text,
-- semantic key, logical profile, or transport detail is included, and no
-- outcome is replayed.
-- ---------------------------------------------------------------------------

local function delivery_failure(result, err)
    if type(result) == "table" then
        local status = result.status
        if status == "rejected" then
            return application_failure("E_OUTPUT_REJECTED", "keyboard output rejected")
        elseif status == "failed" then
            return application_failure("E_OUTPUT_FAILED", "keyboard output failed")
        elseif status == "indeterminate" then
            return application_failure("E_OUTPUT_INDETERMINATE", "keyboard output delivery is uncertain")
        end
        return application_failure("E_OUTPUT_FAILURE", "malformed keyboard output result")
    end
    local code = err and err.error or "E_HOST_FAILURE"
    if code == "E_CANCELLED" then
        return application_failure("E_OUTPUT_CANCELLED", "keyboard output cancelled")
    elseif code == "E_TIMEOUT" then
        return application_failure("E_OUTPUT_TIMEOUT", "keyboard output timed out")
    elseif code == "E_BUSY" then
        return application_failure("E_BUSY", "keyboard output busy")
    elseif code == "E_CLOSED" then
        return application_failure("E_CLOSED", "keyboard output closed")
    elseif code == "E_STALE" then
        return application_failure("E_STALE", "keyboard output stale")
    end
    return application_failure("E_OUTPUT_FAILURE", "keyboard output failed")
end

-- ---------------------------------------------------------------------------
-- Input: transcribe the opaque recording and deliver the transcript once.
-- ---------------------------------------------------------------------------

local function handle_input(event)
    if host_profile == nil then
        return application_failure("E_INVALID_ARGUMENT", "host profile is not configured")
    end
    if type(event) ~= "table" then
        return application_failure("E_INVALID_ARGUMENT", "invalid capture event")
    end
    if event.event ~= channel.CAPTURE_COMPLETE then
        return application_failure("E_INVALID_ARGUMENT", "unsupported event type")
    end
    if type(event.audio) ~= "userdata" then
        return application_failure("E_INVALID_ARGUMENT", "capture audio is missing")
    end

    local result, err = transcription.transcribe(event.audio)
    if result == nil then
        keyboard_log("warn", {
            message = "keyboard_transcription_failed",
            error = err and err.error or "E_HOST_FAILURE",
        })
        return application_failure(err and err.error or "E_HOST_FAILURE", "transcription failed")
    end
    local text, text_err = bounded_transcript_text(result)
    if text == nil then
        keyboard_log("warn", { message = "keyboard_transcription_invalid", error = text_err })
        if text_err == "E_EMPTY" then
            return application_failure("E_INVALID_VALUE", "empty transcription")
        elseif text_err == "E_TOO_LARGE" then
            return application_failure("E_INVALID_VALUE", "transcription too large")
        end
        return application_failure("E_INVALID_VALUE", "malformed transcription result")
    end

    local payload = with_trailing_space(text)
    local outcome, outcome_err = keyboard_output.send_text({ text = payload, profile = host_profile })
    if type(outcome) == "table" and outcome.status == "delivered" then
        keyboard_log("info", { message = "keyboard_delivery", outcome = "delivered", bytes = #payload })
        return { ok = true }
    end
    local failure = delivery_failure(outcome, outcome_err)
    keyboard_log("warn", { message = "keyboard_delivery", outcome = failure.error.code, bytes = #payload })
    return failure
end

-- ---------------------------------------------------------------------------
-- SOS: exactly one semantic Enter through the configured profile.
-- ---------------------------------------------------------------------------

local function handle_sos(event)
    if host_profile == nil then
        return application_failure("E_INVALID_ARGUMENT", "host profile is not configured")
    end
    if type(event) ~= "table" or event.event ~= channel.SOS_TRIGGERED then
        return application_failure("E_INVALID_ARGUMENT", "invalid sos event")
    end
    local outcome, outcome_err = keyboard_output.send_key({ key = "enter", profile = host_profile })
    if type(outcome) == "table" and outcome.status == "delivered" then
        keyboard_log("info", { message = "keyboard_sos", outcome = "delivered" })
        return { ok = true }
    end
    local failure = delivery_failure(outcome, outcome_err)
    keyboard_log("warn", { message = "keyboard_sos", outcome = failure.error.code })
    return failure
end

return {
    startup = startup,
    handle_readiness = handle_readiness,
    handle_input = handle_input,
    handle_sos = handle_sos,
}
